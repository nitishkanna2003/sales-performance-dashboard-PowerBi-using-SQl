-- ============================================================
--  SALES EXTRACTION QUERIES  |  USE sales_db;
--  Run after schema.sql + data_insert.sql
-- ============================================================
USE sales_db;


-- ============================================================
-- Q1: Daily Sales Summary  →  Sheet: "Daily_Sales"
-- ============================================================
SELECT
    DATE(o.order_date)                                              AS sale_date,
    COUNT(DISTINCT o.order_id)                                      AS total_orders,
    COUNT(DISTINCT o.customer_id)                                   AS unique_customers,
    SUM(oi.quantity)                                                AS total_units_sold,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS gross_revenue,
    ROUND(SUM(o.discount), 2)                                       AS total_discounts,
    ROUND(SUM(oi.quantity * oi.unit_price) - SUM(o.discount), 2)   AS net_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY DATE(o.order_date)
ORDER BY sale_date DESC;


-- ============================================================
-- Q2: Monthly Revenue & Gross Margin  →  Sheet: "Monthly_Revenue"
-- ============================================================
SELECT
    DATE_FORMAT(o.order_date, '%Y-%m')                              AS month,
    COUNT(DISTINCT o.order_id)                                      AS orders,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS gross_revenue,
    ROUND(SUM(o.discount), 2)                                       AS discounts,
    ROUND(SUM(oi.quantity * oi.unit_price) - SUM(o.discount), 2)   AS net_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price)
          - SUM(oi.quantity * p.cost_price), 2)                     AS gross_profit,
    ROUND(
        (SUM(oi.quantity * oi.unit_price) - SUM(oi.quantity * p.cost_price))
        / NULLIF(SUM(oi.quantity * oi.unit_price), 0) * 100, 2)    AS gross_margin_pct
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p     ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY month DESC;


-- ============================================================
-- Q3: Revenue by Product & Category  →  Sheet: "Product_Revenue"
-- ============================================================
SELECT
    p.category,
    p.sub_category,
    p.product_name,
    SUM(oi.quantity)                                                AS units_sold,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS revenue,
    ROUND(SUM(oi.quantity * oi.unit_price)
          - SUM(oi.quantity * p.cost_price), 2)                     AS profit,
    ROUND(
        (SUM(oi.quantity * oi.unit_price) - SUM(oi.quantity * p.cost_price))
        / NULLIF(SUM(oi.quantity * oi.unit_price), 0) * 100, 2)    AS margin_pct,
    ROUND(
        SUM(oi.quantity * oi.unit_price)
        / (SELECT SUM(oi2.quantity * oi2.unit_price)
           FROM order_items oi2
           JOIN orders o2 ON oi2.order_id = o2.order_id
           WHERE o2.status NOT IN ('cancelled','refunded')) * 100, 2
    )                                                               AS revenue_share_pct
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o   ON oi.order_id   = o.order_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY p.category, p.sub_category, p.product_name
ORDER BY revenue DESC;


-- ============================================================
-- Q4: Customer LTV & Tier  →  Sheet: "Customer_LTV"
-- ============================================================
SELECT
    c.customer_id,
    c.customer_name,
    c.segment,
    c.city,
    c.country,
    COUNT(DISTINCT o.order_id)                                      AS total_orders,
    MIN(o.order_date)                                               AS first_order_date,
    MAX(o.order_date)                                               AS last_order_date,
    DATEDIFF(MAX(o.order_date), MIN(o.order_date))                  AS customer_age_days,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS lifetime_value,
    ROUND(SUM(oi.quantity * oi.unit_price)
          / NULLIF(COUNT(DISTINCT o.order_id), 0), 2)              AS avg_order_value,
    CASE
        WHEN SUM(oi.quantity * oi.unit_price) >= 50000 THEN 'Platinum'
        WHEN SUM(oi.quantity * oi.unit_price) >= 20000 THEN 'Gold'
        WHEN SUM(oi.quantity * oi.unit_price) >= 5000  THEN 'Silver'
        ELSE 'Bronze'
    END                                                             AS ltv_tier
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY c.customer_id, c.customer_name, c.segment, c.city, c.country
ORDER BY lifetime_value DESC;


-- ============================================================
-- Q5: Regional / Geographic Sales  →  Sheet: "Regional_Sales"
-- ============================================================
SELECT
    c.country,
    c.city,
    o.region,
    COUNT(DISTINCT o.order_id)                                      AS orders,
    COUNT(DISTINCT o.customer_id)                                   AS customers,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS revenue,
    ROUND(SUM(oi.quantity * oi.unit_price)
          - SUM(oi.quantity * p.cost_price), 2)                     AS profit,
    ROUND(AVG(o.total_amount), 2)                                   AS avg_order_value
FROM orders o
JOIN order_items oi ON o.order_id    = oi.order_id
JOIN products p     ON oi.product_id = p.product_id
JOIN customers c    ON o.customer_id = c.customer_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY c.country, c.city, o.region
ORDER BY revenue DESC;


-- ============================================================
-- Q6: Order Status Funnel  →  Sheet: "Order_Status"
-- ============================================================
SELECT
    o.status,
    COUNT(DISTINCT o.order_id)                                      AS order_count,
    ROUND(COUNT(DISTINCT o.order_id) * 100.0
          / (SELECT COUNT(*) FROM orders), 2)                       AS pct_of_total,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS associated_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY o.status
ORDER BY order_count DESC;


-- ============================================================
-- Q7: Top 20 Customers by LTV  →  Sheet: "Top_Customers"
-- ============================================================
SELECT
    c.customer_name,
    c.segment,
    c.country,
    COUNT(DISTINCT o.order_id)                                      AS total_orders,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS lifetime_value,
    ROUND(AVG(o.total_amount), 2)                                   AS avg_order_value
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY c.customer_id, c.customer_name, c.segment, c.country
ORDER BY lifetime_value DESC
LIMIT 20;


-- ============================================================
-- Q8: Discount Impact by Category  →  Sheet: "Discount_Analysis"
-- ============================================================
SELECT
    p.category,
    COUNT(DISTINCT o.order_id)                                      AS orders,
    ROUND(AVG(o.discount), 2)                                       AS avg_discount,
    ROUND(SUM(o.discount), 2)                                       AS total_discounts,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS gross_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price) - SUM(o.discount), 2)   AS net_revenue,
    ROUND(SUM(o.discount)
          / NULLIF(SUM(oi.quantity * oi.unit_price), 0) * 100, 2)  AS discount_rate_pct
FROM orders o
JOIN order_items oi ON o.order_id    = oi.order_id
JOIN products p     ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY p.category
ORDER BY discount_rate_pct DESC;


-- ============================================================
-- Q9: Month-over-Month Revenue Growth  →  Sheet: "MoM_Growth"
-- ============================================================
WITH monthly AS (
    SELECT
        DATE_FORMAT(o.order_date, '%Y-%m')                          AS month,
        ROUND(SUM(oi.quantity * oi.unit_price), 2)                  AS revenue
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    WHERE o.status NOT IN ('cancelled','refunded')
    GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
)
SELECT
    curr.month,
    curr.revenue                                                    AS current_revenue,
    prev.revenue                                                    AS prev_revenue,
    ROUND(curr.revenue - IFNULL(prev.revenue, 0), 2)               AS revenue_change,
    ROUND(
        (curr.revenue - IFNULL(prev.revenue, 0))
        / NULLIF(prev.revenue, 0) * 100, 2)                        AS mom_growth_pct
FROM monthly curr
LEFT JOIN monthly prev ON prev.month = DATE_FORMAT(
    DATE_SUB(STR_TO_DATE(CONCAT(curr.month,'-01'),'%Y-%m-%d'), INTERVAL 1 MONTH), '%Y-%m')
ORDER BY curr.month DESC;


-- ============================================================
-- Q10: Segment Performance  →  Sheet: "Segment_Performance"
-- ============================================================
SELECT
    c.segment,
    COUNT(DISTINCT c.customer_id)                                   AS customers,
    COUNT(DISTINCT o.order_id)                                      AS total_orders,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS gross_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price) - SUM(o.discount), 2)   AS net_revenue,
    ROUND(AVG(o.total_amount), 2)                                   AS avg_order_value,
    ROUND(SUM(oi.quantity * oi.unit_price)
          / COUNT(DISTINCT c.customer_id), 2)                       AS revenue_per_customer
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY c.segment
ORDER BY gross_revenue DESC;


-- ============================================================
-- Q11: Year-over-Year Comparison  →  Sheet: "YoY_Comparison"
-- ============================================================
SELECT
    YEAR(o.order_date)                                              AS year,
    COUNT(DISTINCT o.order_id)                                      AS orders,
    COUNT(DISTINCT o.customer_id)                                   AS customers,
    SUM(oi.quantity)                                                AS units_sold,
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS gross_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price)
          - SUM(oi.quantity * p.cost_price), 2)                     AS gross_profit,
    ROUND(
        (SUM(oi.quantity * oi.unit_price) - SUM(oi.quantity * p.cost_price))
        / NULLIF(SUM(oi.quantity * oi.unit_price), 0) * 100, 2)    AS gross_margin_pct
FROM orders o
JOIN order_items oi ON o.order_id    = oi.order_id
JOIN products p     ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled','refunded')
GROUP BY YEAR(o.order_date)
ORDER BY year;


-- ============================================================
-- Q12: KPI Master Summary Row  →  Sheet: "KPI_Summary"
--      (Single row — perfect for Power BI card visuals)
-- ============================================================
SELECT
    ROUND(SUM(oi.quantity * oi.unit_price), 2)                      AS total_gross_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price) - SUM(o.discount), 2)   AS total_net_revenue,
    ROUND(SUM(oi.quantity * oi.unit_price)
          - SUM(oi.quantity * p.cost_price), 2)                     AS total_gross_profit,
    ROUND(
        (SUM(oi.quantity * oi.unit_price) - SUM(oi.quantity * p.cost_price))
        / NULLIF(SUM(oi.quantity * oi.unit_price), 0) * 100, 2)    AS gross_margin_pct,
    COUNT(DISTINCT o.order_id)                                      AS total_orders,
    ROUND(AVG(o.total_amount), 2)                                   AS avg_order_value,
    COUNT(DISTINCT o.customer_id)                                   AS total_customers,
    ROUND(SUM(oi.quantity * oi.unit_price)
          / NULLIF(COUNT(DISTINCT o.customer_id), 0), 2)           AS revenue_per_customer,
    SUM(oi.quantity)                                                AS total_units_sold,
    ROUND(SUM(o.discount), 2)                                       AS total_discounts_given
FROM orders o
JOIN order_items oi ON o.order_id    = oi.order_id
JOIN products p     ON oi.product_id = p.product_id
WHERE o.status NOT IN ('cancelled','refunded');
